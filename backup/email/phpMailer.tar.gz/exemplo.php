<?php
require_once 'class.smtp.php';
require_once 'class.pop3.php';
require_once 'class.phpmailer.php';




$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Habilitar saída verborrágica

$mail->isSMTP();                                      // Manda usar SMTP
$mail->Host = 'smtp1.example.com;smtp2.example.com';  // Especifica os servidores 
$mail->SMTPAuth = true;                               // Habilita auteticação para SMTP 
$mail->Username = 'user@example.com';                 // usuário SMTP
$mail->Password = 'secret';                           // senha SMTP 
$mail->SMTPSecure = 'tls';                            // Habilita encriptação TLS, SSL também é aceito
$mail->Port = 587;                                    // Porta do servidor de e-mail

$mail->From = 'from@example.com';                     //Remetente
$mail->FromName = 'Mailer';                           //Nome do remetente
$mail->addAddress('joe@example.net', 'Joe User');     //Destinatário com nome
$mail->addAddress('ellen@example.com');               //Destinatário sem nome
$mail->addReplyTo('info@example.com', 'Information'); //Responder para...
$mail->addCC('cc@example.com');                       //Com cópia oculta...
$mail->addBCC('bcc@example.com');                     //Com cópia oculta...

$mail->addAttachment('/var/tmp/file.tar.gz');         //Adiciona anexo
$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Adiciona anexo com outro nome de arquivo
$mail->isHTML(true);                                  //Diz que a mensagem é em html

$mail->Subject = 'Here is the subject';               //Assumto
$mail->Body    = 'This is the HTML message body <b>in bold!</b>'; //Mensagem em html
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients'; //Mensagem alternativa para leitores que não suportam html

//Manda a mensagem
if(!$mail->send()) {
    echo 'Não foi possível enviar';
    echo 'Erro: ' . $mail->ErrorInfo;
} else {
    echo 'Mensagem enviada!';
}
?>
